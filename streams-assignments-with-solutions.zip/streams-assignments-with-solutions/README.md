# Практика по Streams

Небольшой набор задач на методы
 - Stream::map
 - Stream::collect
    - Collectors.groupingBy
    - Collectors.counting
    - Collectors.joining
 - Stream::reduce
 
А также на Optional

Ссылки и примеры по теме:
 - https://annimon.com/article/2778
