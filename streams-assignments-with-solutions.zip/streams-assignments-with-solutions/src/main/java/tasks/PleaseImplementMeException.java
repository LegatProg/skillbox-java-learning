package tasks;

public class PleaseImplementMeException extends RuntimeException {
}
